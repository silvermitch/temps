Configuration APPiis
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install .NET 3.5
    WindowsFeature installdotNet35
    {
      Ensure = �Present�
      Name = �Net-Framework-Core�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP45
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

    #Install ASP .NET 3.5
    WindowsFeature ASP35
    {
      Ensure = �Present�
      Name = �Web-Asp-Net�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }

    # IIS 6 Metabase Compatibility 
    WindowsFeature WebServerLegacyMetabaseCompatibility 
    { 
        Name = "Web-Metabase" 
        Ensure = "Present" 
    } 

  }
} 


