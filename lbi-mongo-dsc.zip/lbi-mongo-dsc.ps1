Configuration DOTNET35
{
  param ($MachineName)

  Node $MachineName
  {
    #Install .NET 3.5
    WindowsFeature installdotNet35
    {
      Ensure = �Present�
      Name = �Net-Framework-Core�
    }
  }
} 


